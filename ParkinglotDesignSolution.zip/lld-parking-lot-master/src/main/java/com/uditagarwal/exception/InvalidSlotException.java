package com.uditagarwal.exception;

/**
 * Exception given when the slot given in input is not a valid slot.
 */
public class InvalidSlotException extends ParkingLotException {

}
